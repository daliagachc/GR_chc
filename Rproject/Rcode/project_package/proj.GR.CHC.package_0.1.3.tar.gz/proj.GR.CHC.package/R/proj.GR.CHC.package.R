#' Project GR CHC package
#'
#' A package that contains the functions used often in the project related
#' analysis. Updated frequently, so it is more to be seen as a way of keeping track of
#' function versions, not a finished package. \cr
#' Newer versions will just be created within the respective folder. Once this package
#' is loaded, you can always update to the newest version by using:  update_me() \cr
#' This works only if you respect the initial folder structure of: \cr
#' projectSpringCourse/Rproject/Rcode/project_package \cr
#' \cr
#' after updating an R restart with .rs.restartR() is recommended.
#'
#'
#' @author Alkuin Koenig \email{alkuin.koenig@gmx.de}
#'
#' @docType package
#'
#' @name proj.GR.CHC.package
NULL
